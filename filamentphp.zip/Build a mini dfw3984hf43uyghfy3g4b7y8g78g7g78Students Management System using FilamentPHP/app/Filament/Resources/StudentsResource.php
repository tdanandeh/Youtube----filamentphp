<?php

namespace App\Filament\Resources;

use App\Exports\StudentExport;
use App\Filament\Resources\StudentsResource\Pages;
use App\Filament\Resources\StudentsResource\RelationManagers;
use App\Models\classes;
use App\Models\sections;
use App\Models\Students;
use Filament\Forms;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Actions\BulkAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class StudentsResource extends Resource
{
    protected static ?string $model = Students::class;

    protected static ?string $navigationLabel = 'مدیریت دانش آموزان';
    protected static ?string $navigationGroup = 'مدیریت دانش آموزان';

    protected static ?string $navigationIcon = 'heroicon-o-user-group';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->required()
                    ->autofocus()
                    ->unique()
                    ->label('نام'),

                TextInput::make('email')
                    ->required()
                    ->label('ایمیل'),

                TextInput::make('address')
                    ->required()
                    ->label('آدرس'),

                TextInput::make('address')
                    ->required()
                    ->autofocus()
                    ->unique()
                    ->tel()
                    ->label('موبایل'),

                Select::make('class_id')
                    ->label('کلاس ')
                    ->options(Classes::all()->pluck('name', 'id'))
                    ->searchable()
                    ->reactive(),
                Select::make('section_id')
                    ->label('بخش ')
                    ->options(function (callable $get) {
                        $classId = $get('class_id');
                        if ($classId) {
                            return sections::where('class_id', $classId)->pluck('name', 'id')->toArray();
                        }
                    })
                    ->searchable()
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->label('نام')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('email')
                    ->label('ایمیل')
                    ->sortable()
                    ->searchable()
                    ->toggleable(),
                TextColumn::make('mobile')
                    ->label('موبایل')
                    ->sortable()
                    ->searchable()
                    ->toggleable(),
                TextColumn::make('address')
                    ->label('آدرس')
                    ->sortable()
                    ->searchable()
                    ->toggleable()
                    ->wrap(),

                TextColumn::make('class.name')
                    ->label('کلاس ')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('section.name')
                    ->label('بخش ')
                    ->sortable()
                    ->searchable(),

            ])
            ->filters([
                Filter::make('class-section-filter')
                    ->form([
                        Select::make('class_id')
                            ->label('فیلتر بر اساس کلاس')
                            ->placeholder('یک کلاس انتخاب کنید')
                            ->options(
                                classes::pluck('name', 'id')->toArray()
                            )
                            ->afterStateUpdated(
                                fn(callable $set) => $set('section_id', null)
                            ),
                        Select::make('section_id')
                            ->label('فیلتر بر اساس بخش')
                            ->placeholder('یک بخش انتخاب کنید')
                            ->options(
                                function (callable $get) {
                                    $classId = $get('class_id');
                                    if ($classId) {
                                        return sections::where('class_id', $classId)->pluck('name', 'id')->toArray();
                                    }
                                }
                            ),

                    ])
                ->query(function (Builder $query, array $data): Builder{
                    return  $query
                        ->when(
                          $data['class_id'],
                            fn(Builder $query, $record ): Builder =>$query->where('class_id',$record),
                        )
                        ->when(
                            $data['section_id'],
                            fn(Builder $query, $record ): Builder =>$query->where('section_id',$record),
                        );
                })

            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make()
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
//                    BulkAction::make('export')
//                        ->label('خروجی اکسل')
//                        ->icon('heroicon-s-arrow-down-tray')
//                        ->requiresConfirmation()
//                        ->action(fn (Collection $records) => (new StudentExport($records))->download('students.xlsx'))
                ]),
                BulkAction::make('export')
                    ->label('خروجی اکسل')
                    ->icon('heroicon-s-arrow-down-tray')
                    ->requiresConfirmation()
                    ->action(fn(Collection $records) => (new StudentExport($records))->download('students.xlsx'))
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListStudents::route('/'),
            'create' => Pages\CreateStudents::route('/create'),
            'edit' => Pages\EditStudents::route('/{record}/edit'),
        ];
    }
    public static function getNavigationBadge(): ?string
    {
        return static::getModel()::count();
    }
    public static function getNavigationBadgeColor(): ?string
    {
        return static::getModel()::count() > 10 ? 'warning' : 'primary';
    }


}
