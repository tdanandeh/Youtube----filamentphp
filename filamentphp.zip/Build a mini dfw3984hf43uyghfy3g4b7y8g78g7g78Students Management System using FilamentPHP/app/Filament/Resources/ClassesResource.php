<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ClassesResource\Pages;
use App\Filament\Resources\ClassesResource\RelationManagers;
use App\Models\Classes;
use App\Models\User;
use Filament\Forms;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class ClassesResource extends Resource
{
    protected static ?string $model = Classes::class;
    protected static ?int $navigationSort = 2;

    protected static ?string $navigationGroup = 'مدیریت موسسه';

    protected static ?string $navigationLabel = 'مدیریت کلاس ها';
    protected static ?string $navigationIcon = 'heroicon-o-academic-cap';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->label('نام')

//                ->numeric()
//                ->nullable()
//                ->prefix('قیمت:')
//                ->suffix('تومان')
//                ->suffixIcon('heroicon-m-globe-alt')
//            Select::make('class_id')
//                ->label('کلاس ')
//                ->options([
//                    'draft' => 'دریافت شده',
//                    'reviewing' => 'Reviewing',
//                    'published' => 'Published',
//                ])
//                ->options(Classes::all()->pluck('name', 'id'))
//                ->searchable()
             ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->label('نام')
                ->sortable(),
                TextColumn::make('sections.name')
                    ->label('بخش ها')
                    ->badge()
                    ->color('success'),
                TextColumn::make('students_count')
                    ->label('تعداد دانش آموزان')
                    ->badge()
                    ->color('primary')
                    ->counts('students')

            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make()
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListClasses::route('/'),
            'create' => Pages\CreateClasses::route('/create'),
            'edit' => Pages\EditClasses::route('/{record}/edit'),
        ];
    }
    public static function getNavigationBadge(): ?string
    {
        return static::getModel()::count();
    }
    public static function getNavigationBadgeColor(): ?string
    {
        return static::getModel()::count() > 10 ? 'danger' : 'primary';
    }
}
