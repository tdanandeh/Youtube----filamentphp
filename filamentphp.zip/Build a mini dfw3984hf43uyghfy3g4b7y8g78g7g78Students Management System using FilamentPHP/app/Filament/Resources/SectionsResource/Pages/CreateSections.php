<?php

namespace App\Filament\Resources\SectionsResource\Pages;

use App\Filament\Resources\SectionsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSections extends CreateRecord
{
    protected static string $resource = SectionsResource::class;
    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
