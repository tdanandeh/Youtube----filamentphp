<?php

namespace App\Filament\Widgets;

use App\Models\students;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class LatestOrders extends BaseWidget
{

    protected static ?int $sort =2;

    protected int | string | array $columnSpan = 'full';


    public function table(Table $table): Table
    {
        return $table
            ->query(
              students::latest()->get(5)


            )
            ->columns([
                TextColumn::make('name')
                    ->label('نام')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('email')
                    ->label('ایمیل')
                    ->sortable()
                    ->searchable()
                    ->toggleable(),
                TextColumn::make('mobile')
                    ->label('موبایل')
                    ->sortable()
                    ->searchable()
                    ->toggleable(),

                TextColumn::make('class.name')
                    ->label('کلاس ')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('section.name')
                    ->label('بخش ')
                    ->sortable()
                    ->searchable(),
            ]);
    }
    protected function isTablePaginationEnabled(): bool
    {
        return false;
    }

}
