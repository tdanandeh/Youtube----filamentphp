<?php

namespace App\Filament\Widgets;

use App\Models\classes;
use App\Models\sections;
use App\Models\students;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class StatsOverview extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            Stat::make('کل دانش آموزان', students::count()),
            Stat::make('تعداد کلاس ها', classes::count()),
            Stat::make('تعداد بخش ها', sections::count()),

        ];
    }
}
