<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class sections extends Model
{
    use HasFactory;
    protected $fillable=['name','class_id'];

    public function class()
    {
        return $this->belongsTo(classes::class,'class_id');
    }
    public function students()
    {
        return $this->hasMany(students::class,'class_id');
    }
}
